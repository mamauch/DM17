#!/usr/bin/env python

"""
Uebung1 DM17 Aprioir Algo
"""

import setuptools

setuptools.setup(
    name='Aprioir Algo',
    description='Simple Apriori algorithm Implementation.',
    long_description=open('README.rst').read(),
    version='0.1.0',
    author='Manuel, Tommy and Marius',
    url='https://github.com/makoeppel/DM17/tree/master/Uebung1',
)
