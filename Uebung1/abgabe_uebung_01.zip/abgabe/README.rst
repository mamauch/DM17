Apriori
======

*Apriori* is a simple implementation of
Apriori algorithm with Python 2.7 and 3.3 - 3.5,

Installation
------------

- Run :code:`python setup.py install`.

Useage
------------


"""
Description: Simple Python implementation of the Apriori Algorithm

Usage:
- Run :code:`mkdir output`
- Run :code:`mkdir data` (Put your data here)
- Run :code:`cd src`
- Run :code:`python apriori.py withTimeOrNot(0,1) -f DATASET.csv -s minSupport`
"""
